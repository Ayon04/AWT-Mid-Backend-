
// employee.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Employee } from './employee.entity';
import { EmployeeService } from './employee.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Employee]), // Import Employee entity into TypeORM
  ],
  providers: [EmployeeService],
  exports: [EmployeeService], // Export EmployeeService if needed
})
export class EmployeeModule {}


/*

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Employee } from './employee.entity'; // Assuming this is your entity
import { EmployeeService } from './employee.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Employee]), // Import Employee entity into TypeORM
  ],
  providers: [EmployeeService],
  exports: [EmployeeService], // Export EmployeeService if needed
})
export class EmployeeModule {}

*/