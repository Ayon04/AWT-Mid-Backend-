import { IsNotEmpty, IsEmail, Length, IsString, Matches, IsIn, IsNumberString, IsInt, Min, Max, IsDate, MinDate } from 'class-validator';
import { PrimaryGeneratedColumn } from 'typeorm';
import { Type } from 'class-transformer';
import { IsUnique, IsEmailEndsWithMediabankbd } from '../admin/admin.dto';


export class EmployeeDTO {

  @PrimaryGeneratedColumn()
  employee_id: string;

  @IsNotEmpty({ message: "Fullname cannot be empty" })
  @IsString({ message: "Please enter a valid fullname" })
  @Matches(/^[A-Za-z-' ']+$/, { message: "Please enter a valid fullname" })
  fullname: string;

  @IsNotEmpty({ message: 'Mobile number cannot be empty' })
  @IsNumberString({}, { message: 'Mobile number must contain only numeric characters' })
  @Matches(/^01\d{9}$/, { message: 'Mobile number must start with 01 and be 11 digits long' })
  @IsUnique({ message: 'Mobile number is already taken', field: 'mobileNo' })
  mobileNo: string;

  @IsNotEmpty({ message: 'NID number cannot be empty' })
  @IsNumberString({}, { message: 'NID No must contain only numeric characters' })
  @IsUnique({ message: 'NID number is already taken', field: 'NID_No' })
  @Matches(/^(19|20)\d{2}\d{6}$/, { message: 'NID No invalid' })
  NID_No: string;

  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Please enter a valid email address' })
  @IsEmailEndsWithMediabankbd({ message: 'Email must end with @mediabankbd.com' })
  @IsUnique({ message: 'Email is already taken', field: 'email' })
  email: string;

  @IsNotEmpty({ message: "Role cannot be empty" })
  @IsString({ message: "Role must be a string" })
  @IsIn(['accountant', 'computer operator', 'cashier', 'customer support', 'loan manager'], { 
    message: "Role must be one of the following: accountant, computer operator, cashier, customer support, loan manager" 
  })
  role: string;

  @IsNotEmpty({ message: "Password cannot be empty" })
  @Length(6, undefined, { message: "Password must be at least 6 characters long" })
  @Matches(/(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{6,}/, {
    message: "Password must contain at least one special character, one numeric digit, and one alphabetic character"
  })
  password: string;


  @IsNotEmpty({ message: "Join date cannot be empty" })
  @IsDate({ message: "Join date must be a valid date" })
  @Type(() => Date)
  joinDate: Date;





  @IsNotEmpty({ message: "Salary cannot be empty" })
  @IsInt({ message: "Salary must be an integer" })
  @Min(20000, { message: "Salary must be at least 20000" })
  @Max(150000, { message: "Salary must be at most 150000" })
  salary: number;

  @IsNotEmpty({ message: "Branch cannot be empty" })
  @IsString({ message: "Branch must be a string" })
  @IsIn(['Bashundhara', 'Uttara', 'Kuril', 'Dhanmondi', 'Badda', 'Rampura', 'Mogbazar', 'Malibagh', 'Mirpur'], { 
    message: "Branch must be one of the following: Bashundhara, Uttara, Kuril, Dhanmondi, Badda, Rampura, Mogbazar, Malibagh, Mirpur" 
  })
  branch: string;

  @IsNotEmpty({ message: "Status cannot be empty" })
  @IsString({ message: "Status must be a string" })
  @IsIn(['block', 'active'], { message: "Status must be either 'block' or 'active'" })
  status: string ;

  
}





export class EmployeeUpdateDTO{

  @IsNotEmpty({ message: "enter employee id " })
  employee_id: number;

  @IsNotEmpty({ message: "Fullname cannot be empty" })
  @IsString({ message: "Please enter a valid fullname" })
  @Matches(/^[A-Za-z-' ']+$/, { message: "Please enter a valid fullname" })
  fullname: string;

  @IsNotEmpty({ message: 'Mobile number cannot be empty' })
  @IsNumberString({}, { message: 'Mobile number must contain only numeric characters' })
  @Matches(/^01\d{9}$/, { message: 'Mobile number must start with 01 and be 11 digits long' })
  @IsUnique({ message: 'Mobile number is already taken', field: 'mobileNo' })
  mobileNo: string;

  @IsNotEmpty({ message: 'NID number cannot be empty' })
  @IsNumberString({}, { message: 'NID No must contain only numeric characters' })
  @IsUnique({ message: 'NID number is already taken', field: 'NID_No' })
  @Matches(/^(19|20)\d{2}\d{6}$/, { message: 'NID No invalid' })
  NID_No: string;

  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Please enter a valid email address' })
  @IsEmailEndsWithMediabankbd({ message: 'Email must end with @mediabankbd.com' })
  @IsUnique({ message: 'Email is already taken', field: 'email' })
  email: string;

  @IsNotEmpty({ message: "Role cannot be empty" })
  @IsString({ message: "Role must be a string" })
  @IsIn(['accountant', 'computer operator', 'cashier', 'customer support', 'loan manager'], { 
    message: "Role must be one of the following: accountant, computer operator, cashier, customer support, loan manager" 
  })
  role: string;

  @IsNotEmpty({ message: "Password cannot be empty" })
  @Length(6, undefined, { message: "Password must be at least 6 characters long" })
  @Matches(/(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{6,}/, {
    message: "Password must contain at least one special character, one numeric digit, and one alphabetic character"
  })
  password: string;


  @IsNotEmpty({ message: "Join date cannot be empty" })
  @IsDate({ message: "Join date must be a valid date" })
  @Type(() => Date)
  joinDate: Date;





  @IsNotEmpty({ message: "Salary cannot be empty" })
  @IsInt({ message: "Salary must be an integer" })
  @Min(20000, { message: "Salary must be at least 20000" })
  @Max(150000, { message: "Salary must be at most 150000" })
  salary: number;

  @IsNotEmpty({ message: "Branch cannot be empty" })
  @IsString({ message: "Branch must be a string" })
  @IsIn(['Bashundhara', 'Uttara', 'Kuril', 'Dhanmondi', 'Badda', 'Rampura', 'Mogbazar', 'Malibagh', 'Mirpur'], { 
    message: "Branch must be one of the following: Bashundhara, Uttara, Kuril, Dhanmondi, Badda, Rampura, Mogbazar, Malibagh, Mirpur" 
  })
  branch: string;

  @IsNotEmpty({ message: "Status cannot be empty" })
  @IsString({ message: "Status must be a string" })
  @IsIn(['block', 'active'], { message: "Status must be either 'block' or 'active'" })
  status: string ;

  
}