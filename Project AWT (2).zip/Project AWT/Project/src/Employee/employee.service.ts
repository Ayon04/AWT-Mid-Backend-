import { Injectable, InternalServerErrorException, ConflictException,NotFoundException,HttpStatus,HttpException} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Employee } from './employee.entity';
import { EmployeeDTO,EmployeeUpdateDTO } from './employee.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class EmployeeService {
  constructor(
    @InjectRepository(Employee)
    private readonly employeeRepository: Repository<Employee>,
  ) {}

  async isMobileNoTaken(mobileNo: string): Promise<boolean> {
    const existingEmployee = await this.employeeRepository.findOne({ where: { mobileNo } });
    return !!existingEmployee;
  }

  async isNIDNoTaken(NID_No: string): Promise<boolean> {
    const existingEmployee = await this.employeeRepository.findOne({ where: { NID_No } });
    return !!existingEmployee;
  }

  async isEmailTaken(email: string): Promise<boolean> {
    const existingEmployee = await this.employeeRepository.findOne({ where: { email } });
    return !!existingEmployee;
  }

  async insertEmployee(employeeDTO: EmployeeDTO, adminId: string): Promise<Employee> {
    try {
      const { fullname, mobileNo, NID_No, email, role, password, joinDate, salary, branch, status } = employeeDTO;

      const mobileNoTaken = await this.isMobileNoTaken(mobileNo);
      const NIDNoTaken = await this.isNIDNoTaken(NID_No);
      const emailTaken = await this.isEmailTaken(email);

      if (mobileNoTaken) {
        throw new ConflictException('Mobile number is already taken');
      }

      if (NIDNoTaken) {
        throw new ConflictException('NID number is already taken');
      }

      if (emailTaken) {
        throw new ConflictException('Email is already taken');
      }

      const employee = new Employee();
      employee.fullname = fullname;
      employee.mobileNo = mobileNo;
      employee.NID_No = NID_No;
      employee.email = email;
      employee.role = role;

      const salt = await bcrypt.genSalt();
      const hashedPassword = await bcrypt.hash(password, salt);
      employee.password = hashedPassword;
      employee.joinDate = joinDate;
      employee.salary = salary;
      employee.branch = branch;
      employee.status = status;
      employee.admin_id = adminId; // Assign admin ID to employee record

      const savedEmployee = await this.employeeRepository.save(employee);
      return savedEmployee;
    } catch (error) {
      console.error('Error inserting employee:', error);
      if (error instanceof ConflictException) {
        throw error;
      }
      throw new InternalServerErrorException('Failed to create employee');
    }
  }

  

  async findEmpById(employee_id: number): Promise<Employee | null> {
    return this.employeeRepository.findOne({ where: { employee_id } }) || null;
  }



  async updateEmployee(admin_id: number, employeeUpdateDTO: EmployeeUpdateDTO): Promise<Employee> {
    try {
      const { employee_id, fullname, mobileNo, NID_No, email, role, password, joinDate, salary, branch, status } = employeeUpdateDTO;
  
      const employee = await this.findEmpById(employee_id);
      if (!employee) {
        throw new NotFoundException('Employee not found');
      }
  
      // Check if new mobileNo is different from current one and if it is already taken
      if (mobileNo && mobileNo !== employee.mobileNo) {
        const mobileNoTaken = await this.isMobileNoTaken(mobileNo);
        if (mobileNoTaken) {
          throw new ConflictException('Mobile number is already taken');
        }
      }
  
      // Check if new NID_No is different from current one and if it is already taken
      if (NID_No && NID_No !== employee.NID_No) {
        const NIDNoTaken = await this.isNIDNoTaken(NID_No);
        if (NIDNoTaken) {
          throw new ConflictException('NID number is already taken');
        }
      }
  
      // Check if new email is different from current one and if it is already taken
      if (email && email !== employee.email) {
        const emailTaken = await this.isEmailTaken(email);
        if (emailTaken) {
          throw new ConflictException('Email is already taken');
        }
      }
  
      // Update only the fields that have changed
      employee.fullname = fullname || employee.fullname;
      employee.mobileNo = mobileNo || employee.mobileNo;
      employee.NID_No = NID_No || employee.NID_No;
      employee.email = email || employee.email;
      employee.role = role || employee.role;
  
      if (password) {
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(password, salt);
        employee.password = hashedPassword;
      }
  
      employee.joinDate = joinDate || employee.joinDate;
      employee.salary = salary || employee.salary;
      employee.branch = branch || employee.branch;
      employee.status = status || employee.status;
  
      const savedEmployee = await this.employeeRepository.save(employee);
      return savedEmployee;
    } catch (error) {
      console.error('Error updating employee:', error);
      if (error instanceof ConflictException || error instanceof NotFoundException) {
        throw error;
      }
      throw new HttpException('Failed to update employee', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }



  async deleteEmployee(employee_id: number): Promise<void> {
    const employee = await this.findEmpById(employee_id);
    if (!employee) {
      throw new NotFoundException('Employee not found');
    }
    await this.employeeRepository.delete(employee_id);
  }
  

  async findAll(): Promise<Employee[]> {
    return this.employeeRepository.find();
  }



  async findEmployeeById(id: number): Promise<Employee> {
    return this.employeeRepository.findOneBy({ employee_id: id }); // Ensure employee_id is the correct column name
  }

  async findEmployeesByBankName(bankName: string): Promise<Employee[]> {
    return this.employeeRepository.find({
      where: { branch: bankName }, 
    });
  }

}
