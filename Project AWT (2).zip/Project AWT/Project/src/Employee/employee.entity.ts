import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";

import { AdminProfile} from "../admin/admin.entity";

@Entity("employeeentity")
export class Employee {
    @PrimaryGeneratedColumn()
    employee_id: number;

    @Column()
    fullname: string;

    @Column()
    mobileNo: string;

    @Column()
    NID_No: string;

    @Column()
    email: string;

    @Column()
    role: string;

    @Column()
    joinDate: Date;

    @Column()
    salary: number;

    @Column()
    branch: string;

    @Column()
    password: string;

    @Column()
    status: string;

    @Column()
  admin_id: string;

    @ManyToOne(() => AdminProfile, admin => admin.employee)
    admin: AdminProfile;

 

}
