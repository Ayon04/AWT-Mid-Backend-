

import { Injectable } from '@nestjs/common';
import { MailerService } from '@nestjs-modules/mailer';

@Injectable()
export class CustomMailerService {
  constructor(private readonly mailerService: MailerService) {}

  async sendPasswordResetMail(email: string, username: string, otp: string) {
    try {
      await this.mailerService.sendMail({
        to: email,
        subject: 'Password Reset Request',
        text: `Hello ${username},\n\nYour OTP for password reset is: ${otp}\n\nPlease use this OTP to reset your password.`,
      });
      console.log('Password reset email sent successfully');
    } catch (error) {
      console.error('Error sending password reset email:', error);
    }
  }
}
