// src/auth/auth.controller.ts
/*
import { Controller, Post, Body, Res, HttpStatus, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { Response } from 'express';
import { SignInDTO } from '../admin.dto'; // Adjust path based on actual structure

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('signin')
  async signIn(@Body() body: SignInDTO, @Res() res: Response) {
    try {
      const loginResult = await this.authService.signIn(body);
      res.cookie('jwt', loginResult.access_token, {
        httpOnly: true,
        maxAge: 300000, // 5 minutes
      });
      return res.status(HttpStatus.OK).json(loginResult);
    } catch (error) {
      throw new UnauthorizedException('Invalid username or password');
    }
  }
}
*/