import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { AdminProfile } from '../admin.entity';

@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  async signIn(admin: AdminProfile): Promise<string> {
    const payload = { username: admin.username, sub: admin.admin_id };
    return this.jwtService.sign(payload);
  }
}
