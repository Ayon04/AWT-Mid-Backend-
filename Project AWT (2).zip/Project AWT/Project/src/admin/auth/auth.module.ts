import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { AdminProfile } from '../admin.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forFeature([AdminProfile]),
    JwtModule.register({
      secret: 'yourSecretKey', // replace with your own secret key
      signOptions: { expiresIn: '300s' }, // 5 minutes
    }),
  ],
  providers: [AuthService],
  exports: [AuthService, JwtModule], // Export JwtModule here
})
export class AuthModule {}
