import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminProfile } from './admin.entity';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { AuthModule } from './auth/auth.module';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';
import { EmployeeModule } from 'src/Employee/employee.module';
import { BankModule } from 'src/Bank/bank.module';
import { CustomMailerModule } from './mailer.module'; // Adjust the import path as needed

@Module({
  imports: [
    TypeOrmModule.forFeature([AdminProfile]),
    AuthModule,
    EmployeeModule,
    BankModule,
    CustomMailerModule, // Import CustomMailerModule here
    JwtModule.register({
      secret: 'your-secret-key',
      signOptions: { expiresIn: '60m' },
    }),
  ],
  controllers: [AdminController],
  providers: [AdminService, AuthService, AuthGuard],
})
export class AdminModule {}
