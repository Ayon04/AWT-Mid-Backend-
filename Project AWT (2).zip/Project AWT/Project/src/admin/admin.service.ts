import { Injectable, HttpException, HttpStatus } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { AdminProfile } from "./admin.entity";
import { Repository } from "typeorm";
import { AdminDTO, AdminUpdateDTO, SignInDTO,AdminChangePasswordDTO } from "./admin.dto";
import * as bcrypt from 'bcrypt';
import { CustomMailerService } from './mailer.service';

import { } from "@nestjs-modules/mailer";

import{randomBytes} from 'crypto';

@Injectable()
export class AdminService {
  constructor(
    @InjectRepository(AdminProfile) private adminRepo: Repository<AdminProfile>,
    private readonly customMailerService: CustomMailerService,
  ) {}

  async isUsernameTaken(username: string): Promise<boolean> {
    const existingAdmin = await this.adminRepo.findOne({ where: { username } });
    return !!existingAdmin;
  }

  async isEmailTaken(email: string): Promise<boolean> {
    const existingAdmin = await this.adminRepo.findOne({ where: { email } });
    return !!existingAdmin;
  }

  async isMobileNumberTaken(mobileNumber: string): Promise<boolean> {
    const existingAdmin = await this.adminRepo.findOne({ where: { mobileNumber } });
    return !!existingAdmin;
  }

  async addAdmin(adminDTO: AdminDTO): Promise<AdminProfile> {
    try {
      const usernameTaken = await this.isUsernameTaken(adminDTO.username);
      const emailTaken = await this.isEmailTaken(adminDTO.email);
      const mobileNumberTaken = await this.isMobileNumberTaken(adminDTO.mobileNumber);

      if (usernameTaken) {
        throw new HttpException('Username is already taken', HttpStatus.CONFLICT);
      }

      if (emailTaken) {
        throw new HttpException('Email is already taken', HttpStatus.CONFLICT);
      }

      if (mobileNumberTaken) {
        throw new HttpException('Mobile number is already taken', HttpStatus.CONFLICT);
      }

      const adminProfile = new AdminProfile();
      adminProfile.fullname = adminDTO.fullname;
      adminProfile.username = adminDTO.username;
      adminProfile.mobileNumber = adminDTO.mobileNumber;
      adminProfile.email = adminDTO.email;

      // Hash the password
      const salt = await bcrypt.genSalt();
      const hashedPassword = await bcrypt.hash(adminDTO.password, salt);
      adminProfile.password = hashedPassword;

      const savedAdmin = await this.adminRepo.save(adminProfile);

      console.log('Admin Signup Successful');

      return savedAdmin;

    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      } else {
        throw new HttpException('Failed to signup admin', HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }
  }

  async findAdminByUsername(username: string): Promise<AdminProfile | undefined> {
    return this.adminRepo.findOne({ where: { username } });
  }

  async findAdminById(admin_id: number): Promise<AdminProfile | null> {
    return this.adminRepo.findOne({ where: { admin_id } }) || null;
  }

  async saveAdmin(admin: AdminProfile): Promise<AdminProfile> {
    const hashedPassword = await bcrypt.hash(admin.password, 10); // 10 is the saltRounds
    admin.password = hashedPassword; // Update hashed password in the admin object
    return this.adminRepo.save(admin);
  }


/*
  async updateAdminProfile(admin_id: number, updateAdminProfileDTO: AdminUpdateDTO): Promise<object> {

    try {
      const usernameTaken = await this.isUsernameTaken(updateAdminProfileDTO.username);
      const emailTaken = await this.isEmailTaken(updateAdminProfileDTO.email);
      const mobileNumberTaken = await this.isMobileNumberTaken(updateAdminProfileDTO.mobileNumber);

      if (usernameTaken) {
        throw new HttpException('Username is already taken', HttpStatus.CONFLICT);
      }

      if (emailTaken) {
        throw new HttpException('Email is already taken', HttpStatus.CONFLICT);
      }

      if (mobileNumberTaken) {
        throw new HttpException('Mobile number is already taken', HttpStatus.CONFLICT);
      }



    const admin = await this.findAdminById(admin_id);
    if (admin) {
      admin.fullname = updateAdminProfileDTO.fullname;
      admin.username = updateAdminProfileDTO.username;
      admin.email = updateAdminProfileDTO.email;
      admin.mobileNumber = updateAdminProfileDTO.mobileNumber;
     

      const updatedAdmin = await this.adminRepo.save(admin);
      return {
        message: "Admin updated successfully",
        updatedAdmin: updatedAdmin,
      };
    } else {
      return { message: "Admin update failed" };
    }
  }

  catch (error) {
    if (error instanceof HttpException) {
      throw error;
    } else {
      throw new HttpException('Failed to update admin', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}
  
*/

async updateAdminProfile(admin_id: number, updateAdminProfileDTO: AdminUpdateDTO): Promise<object> {
  try {
    const admin = await this.findAdminById(admin_id);

    if (!admin) {
      return { message: "Admin update failed" };
    }

    // Only check if the new values are different from the current ones
    if (updateAdminProfileDTO.username !== admin.username) {
      const usernameTaken = await this.isUsernameTaken(updateAdminProfileDTO.username);
      if (usernameTaken) {
        throw new HttpException('Username is already taken', HttpStatus.CONFLICT);
      }
    }

    if (updateAdminProfileDTO.email !== admin.email) {
      const emailTaken = await this.isEmailTaken(updateAdminProfileDTO.email);
      if (emailTaken) {
        throw new HttpException('Email is already taken', HttpStatus.CONFLICT);
      }
    }

    if (updateAdminProfileDTO.mobileNumber !== admin.mobileNumber) {
      const mobileNumberTaken = await this.isMobileNumberTaken(updateAdminProfileDTO.mobileNumber);
      if (mobileNumberTaken) {
        throw new HttpException('Mobile number is already taken', HttpStatus.CONFLICT);
      }
    }

    // Update only the fields that have changed
    admin.fullname = updateAdminProfileDTO.fullname;
    if (updateAdminProfileDTO.username !== admin.username) {
      admin.username = updateAdminProfileDTO.username;
    }
    if (updateAdminProfileDTO.email !== admin.email) {
      admin.email = updateAdminProfileDTO.email;
    }
    if (updateAdminProfileDTO.mobileNumber !== admin.mobileNumber) {
      admin.mobileNumber = updateAdminProfileDTO.mobileNumber;
    }

    const updatedAdmin = await this.adminRepo.save(admin);
    return {
      message: "Admin updated successfully",
      updatedAdmin: updatedAdmin,
    };

  } catch (error) {
    if (error instanceof HttpException) {
      throw error;
    } else {
      throw new HttpException('Failed to update admin', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}



async changeAdminPassword(adminId: number, adminChangePasswordDTO: AdminChangePasswordDTO): Promise<object> {
  const { currentpassword, newpassword } = adminChangePasswordDTO;
  
  const admin = await this.findAdminById(adminId);
  if (!admin) {
    throw new HttpException('Admin not found', HttpStatus.NOT_FOUND);
  }

  const isMatch = await bcrypt.compare(currentpassword, admin.password);
  if (!isMatch) {
    throw new HttpException('Current password is incorrect', HttpStatus.BAD_REQUEST);
  }

  const hashedNewPassword = await bcrypt.hash(newpassword, 10);
  admin.password = hashedNewPassword;
  
  await this.adminRepo.save(admin);

  return { message: "Password changed successfully" };
}
///mailer--------------------------------

async requestPasswordReset(username: string, email: string): Promise<void> {
  const admin = await this.adminRepo.findOne({ where: { username, email } });
  
  if (!admin) {
    throw new HttpException('User not found', HttpStatus.NOT_FOUND);
  }
  
  // Generate a 6-digit OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString(); 

  // Save OTP in the database
  admin.resetOtp = otp; // Ensure this column exists in your AdminProfile entity
  await this.adminRepo.save(admin);

  // Send OTP email
  await this.customMailerService.sendPasswordResetMail(email, username, otp); // Call the mailer method here
}


async resetPassword(username: string, email: string, otp: string, newPassword: string): Promise<void> {
  const admin = await this.adminRepo.findOne({ where: { username, email, resetOtp: otp } });

  if (!admin) {
    throw new HttpException('Invalid OTP, username, or email', HttpStatus.BAD_REQUEST);
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);
  admin.password = hashedPassword;
  admin.resetOtp = null; // Clear OTP after password reset
  await this.adminRepo.save(admin);
}



async handlePasswordReset(
  username: string,
  email: string,
  newPassword?: string,
  otp?: string
): Promise<object> {
  if (newPassword && otp) {
    await this.resetPassword(username, email, otp, newPassword);
    return { message: 'Password reset successful' };
  } else {
    await this.requestPasswordReset(username, email);
    return { message: 'OTP sent to your registered email address' };
  }
}


}
 

