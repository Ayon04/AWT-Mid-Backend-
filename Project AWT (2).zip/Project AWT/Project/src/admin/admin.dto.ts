import { Injectable } from '@nestjs/common';
import { AdminService } from './admin.service';
import { IsNumberString, Length, IsEmail, IsNotEmpty, IsString, Matches, registerDecorator, ValidationOptions, ValidationArguments } from "class-validator";
import { isReadable } from 'stream';

export function IsUnique(validationOptions: { message: string, field: keyof any }, validationDecoratorOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isUnique',
      target: object.constructor,
      propertyName: propertyName,
      options: validationDecoratorOptions,
      async validator(value: any, args: ValidationArguments) {
        const adminService: AdminService = (args.object as any).adminService;
        if (!adminService) {
          throw new Error('AdminService is not available in the validation context.');
        }
        const field = validationOptions.field as keyof AdminDTO;
        const existingAdmin = await adminService[`getAdminBy${field.charAt(0).toUpperCase() + field.slice(1)}`](value);
        return !existingAdmin; // Return true if not found (i.e., unique), false if found (not unique)
      },
      
    });
  };

}



export class AdminDTO {

  admin_id: string;

  @IsString({ message: "Please enter a valid fullname" })
  @Matches(/^[A-Za-z-' ']+$/, { message: "Please enter a valid fullname" })
  @IsNotEmpty({ message: "fullname can not be empty" })
  fullname: string;

  @IsNotEmpty({ message: "username cannot be empty" })
  @IsString({ message: "Please enter a valid USERNAME" })
  @Length(4, 6, { message: 'Username must be between 4 and 6 characters' })
  @IsUnique({ message: 'Username is already taken', field: 'username' })
  username: string;

  @IsNotEmpty({ message: 'Mobile number cannot be empty' })
  @IsNumberString({}, { message: 'Mobile number must contain only numeric characters' })
  @Matches(/^01\d{9}$/, { message: 'Mobile number must start with 01 and be 11 digits long' })
  @IsUnique({ message: 'Mobile number is already taken', field: 'mobileNumber' })
  mobileNumber: string;

  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Please enter a valid email address' })
  //@IsEmailEndsWithMediabankbd({ message: 'Email must end with @mediabankbd.com' })
  @IsUnique({ message: 'Email is already taken', field: 'email' })
  email: string;

  @IsNotEmpty({ message: "Password cannot be empty" })
  @Length(6, undefined, { message: "Password must be at least 6 characters long" })
  @Matches(/(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{6,}/, {
    message: "Password must contain at least one special character, one numeric digit, and one alphabetic character"
  })
  password: string;

}


export function IsEmailEndsWithMediabankbd(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isEmailEndsWithMediabankbd',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: any, args: ValidationArguments) {
          return typeof value === 'string' && value.endsWith('@mediabankbd.com');
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must end with @mediabankbd.com`;
        },
      },
    });
  };


 
}



export class SignInDTO {
  @IsNotEmpty({ message: "username cannot be empty" })
  @IsString({ message: "Please enter a valid USERNAME" })
  @Length(4, 6, { message: 'Username must be between 4 and 6 characters' })
  username: string;


  @IsNotEmpty({ message: "Password cannot be empty" })
  @Length(6, undefined, { message: "Password must be at least 6 characters long" })
  
  password: string;

  


}



export class AdminUpdateDTO  {
  
  

  admin_id: string;
  @IsString({ message: "Please enter a valid fullname" })
  @Matches(/^[A-Za-z-' ']+$/, { message: "Please enter a valid fullname" })
  @IsNotEmpty({ message: "fullname can not be empty" })
  fullname: string;

  @IsNotEmpty({ message: "username cannot be empty" })
  @IsString({ message: "Please enter a valid USERNAME" })
  @Length(4, 6, { message: 'Username must be between 4 and 6 characters' })
  @IsUnique({ message: 'Username is already taken', field: 'username' })
  username: string;

  @IsNotEmpty({ message: 'Mobile number cannot be empty' })
  @IsNumberString({}, { message: 'Mobile number must contain only numeric characters' })
  @Matches(/^01\d{9}$/, { message: 'Mobile number must start with 01 and be 11 digits long' })
  @IsUnique({ message: 'Mobile number is already taken', field: 'mobileNumber' })
  mobileNumber: string;

  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Please enter a valid email address' })
  @IsEmailEndsWithMediabankbd({ message: 'Email must end with @mediabankbd.com' })
  @IsUnique({ message: 'Email is already taken', field: 'email' })
  email: string;

}



export class AdminChangePasswordDTO  {
  
  @IsNotEmpty({ message: "Password cannot be empty" })
  @Length(6, undefined, { message: "Password must be at least 6 characters long" })
  @Matches(/(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{6,}/, {
    message: "Password must contain at least one special character, one numeric digit, and one alphabetic character"
  })
  currentpassword: string;

 

  @IsNotEmpty({ message: "Password cannot be empty" })
  @Length(6, undefined, { message: "Password must be at least 6 characters long" })
  @Matches(/(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{6,}/, {
    message: "Password must contain at least one special character, one numeric digit, and one alphabetic character"
  })
  newpassword: string;

  
 

 

}

