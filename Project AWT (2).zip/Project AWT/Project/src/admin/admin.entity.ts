import { Employee } from "../Employee/employee.entity";
import {HttpCode,HttpException,HttpStatus, Body, Delete, Controller, Get, Param, ParseIntPipe, Post, Put, UsePipes, ValidationPipe } from "@nestjs/common";


import { PrimaryGeneratedColumn, Column, Entity, OneToMany, BeforeInsert } from "typeorm";

@Entity("adminentity")
export class AdminProfile {
  @PrimaryGeneratedColumn()//{ primary: true }
  admin_id: number;

  @Column()
  fullname: string;

  @Column()
  username: string;

  @Column()
  mobileNumber: string;

  @Column()
  email: string;

  @Column()

  password: string;

  @Column({ nullable: true })
  resetOtp: string;

  @OneToMany(() => Employee,employee => employee)
  employee: Employee[];
/*

  @OneToMany(() => Transaction, (transaction) => transaction.admin)
  transactions: Transaction[];

  @OneToMany(() => Loan, (loan) => loan.admin)
  loans: Loan[];

  @OneToMany(() => Account, (account) => account.admin)
  accounts: Account[];

*/

}
