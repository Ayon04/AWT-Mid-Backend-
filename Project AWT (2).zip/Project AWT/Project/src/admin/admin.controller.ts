import { UseInterceptors,UploadedFile,Controller, Put, Delete, Get, Post, Body, BadRequestException,UsePipes, ValidationPipe, Res, UseGuards, Req, HttpStatus, HttpException, UnauthorizedException, Patch } from '@nestjs/common';
import { AdminService } from './admin.service';
import { SignInDTO, AdminDTO, AdminUpdateDTO, AdminChangePasswordDTO } from './admin.dto';
import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';
import { Response, Request } from 'express';
import { EmployeeDTO, EmployeeUpdateDTO } from '../Employee/employee.dto';
import { EmployeeService } from '../Employee/employee.service';
import { Employee } from 'src/Employee/employee.entity';
import * as bcrypt from 'bcrypt';
import { customer } from 'src/Bank/bank.entity';
import { BankService } from 'src/Bank/bank.service';
import {Loan,Account,Transaction,Performance} from 'src/Bank/bank.entity'
import { FileInterceptor } from '@nestjs/platform-express';
import { Policy } from '../Bank/bank.entity'; // Adjust the path as necessary
import { MulterError } from 'multer'; // Import MulterError
@Controller('admin')
export class AdminController {
  constructor(
    private readonly adminService: AdminService,
    private readonly authService: AuthService,
    private readonly employeeService: EmployeeService,
    private readonly bankService: BankService, // Inject BankService here
    
  ) {}

  @Post('signup')
  @UsePipes(new ValidationPipe())
  addAdmin(@Body() myobj: AdminDTO) {
    return this.adminService.addAdmin(myobj);
  }

  @Post('signin')
  @UsePipes(new ValidationPipe())
  async signIn(@Body() obj: SignInDTO, @Res() res: Response) {
    const admin = await this.adminService.findAdminByUsername(obj.username);
    
    if (!admin) {
      throw new UnauthorizedException('Invalid username or password');
    }

    const passwordMatches = await bcrypt.compare(obj.password, admin.password);
    
    if (!passwordMatches) {
      throw new UnauthorizedException('Invalid username or password');
    }

    const token = await this.authService.signIn(admin);
    res.cookie('jwt', token, {
      httpOnly: true,
      maxAge: 300000,
    });
    return res.status(HttpStatus.OK).json({ token });
  }

  @Post('signout')
  async signOut(@Res() res: Response) {
    res.clearCookie('jwt');
    return res.status(HttpStatus.OK).json({ message: 'You have signed out' });
  }

  @Get('profile')
  @UseGuards(AuthGuard)
  async getProfile(@Req() req: Request, @Res() res: Response) {
    const admin = req['admin'];
    const adminProfile = await this.adminService.findAdminById(admin.sub);
    return res.status(HttpStatus.OK).json(adminProfile);
  }

  @Put('profileupdate')
  @UseGuards(AuthGuard)
  @UsePipes(new ValidationPipe())
  async updateProfile(@Req() req: Request, @Res() res: Response, @Body() updateAdminProfileDTO: AdminUpdateDTO) {
    const admin = req['admin'];
    const updatedAdminProfile = await this.adminService.updateAdminProfile(admin.sub, updateAdminProfileDTO);
    return res.status(HttpStatus.OK).json(updatedAdminProfile);
  }

  @Patch('changepassword')
  @UseGuards(AuthGuard)
  @UsePipes(new ValidationPipe())
  async changePassword(@Req() req: Request, @Res() res: Response, @Body() adminChangePasswordDTO: AdminChangePasswordDTO) {
    const admin = req['admin'];
    const result = await this.adminService.changeAdminPassword(admin.sub, adminChangePasswordDTO);
    return res.status(HttpStatus.OK).json(result);
  }

  @Post('addemployee')
  @UseGuards(AuthGuard)
  @UsePipes(new ValidationPipe())
  async createEmployee(
    @Body() createEmployeeDTO: EmployeeDTO, 
    @Req() req: Request, 
    @Res() res: Response
  ) {
    try {
      const adminId = req['admin'].sub;
      const result = await this.employeeService.insertEmployee(createEmployeeDTO, adminId);
      return res.status(HttpStatus.CREATED).json(result);
    } catch (error) {
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({ message: 'Failed to create employee', error });
    }
  }

  @Put('empupdate')
  @UseGuards(AuthGuard)
  @UsePipes(new ValidationPipe())
  async updateEmployee(
    @Req() req: Request,
    @Body() employeeUpdateDTO: EmployeeUpdateDTO,
  ) {
    try {
      const admin = req['admin'];
      const admin_id = admin.sub; 

      const updatedEmployee = await this.employeeService.updateEmployee(admin_id, employeeUpdateDTO);
      return { message: 'Employee updated successfully', updatedEmployee };
    } catch (error) {
      throw new HttpException(error.message || 'Failed to update employee', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Delete('empdelete')
  @UseGuards(AuthGuard)
  async deleteEmployee(@Req() req: Request, @Body('employee_id') employee_id: number) {
    try {
      const admin = req['admin'];
      await this.employeeService.deleteEmployee(employee_id);
      return { message: 'Employee deleted successfully' };
    } catch (error) {
      throw new HttpException(error.message || 'Failed to delete employee', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Get('allemployee')
  @UseGuards(AuthGuard)
  async getAllEmployees(): Promise<Employee[]> {
    return this.employeeService.findAll();
  }

  @Get('allcustomer')
  @UseGuards(AuthGuard)
  async getAllCustomers(): Promise<customer[]> {
    return this.bankService.findAllCustomers(); // Use bankService to get customers
  }


  @Get('allaccounts')
  async getAllAccounts(): Promise<Account[]> {
    return this.bankService.findAllAccounts();
  }

  @Get('allloans')
  async getAllLoans(): Promise<Loan[]> {
    return this.bankService.findAllLoans();
  }

  @Get('alltransactions')
  async getAllTransactions(): Promise<Transaction[]> {
    return this.bankService.findAllTransactions();
  }

  @Get('allperformances')
  async getAllPerformances(): Promise<Performance[]> {
    return this.bankService.findAllPerformances();
  }



  @Get('employeeById')
  @UseGuards(AuthGuard)
  async getEmployeeById(@Body('id') id: number): Promise<Employee> {
    return this.employeeService.findEmployeeById(id);
  }

  @Get('employeesByBankName')
  @UseGuards(AuthGuard)
  async getEmployeesByBankName(@Body('bankName') bankName: string): Promise<Employee[]> {
    return this.employeeService.findEmployeesByBankName(bankName);
  }

  @Get('customerById')
  @UseGuards(AuthGuard)
  async getCustomerById(@Body('id') id: number): Promise<customer> {
    return this.bankService.findCustomerById(id);
  }

  @Get('customersByBankName')
  @UseGuards(AuthGuard)
  async getCustomersByBankName(@Body('bankName') bankName: string): Promise<customer[]> {
    return this.bankService.findCustomersByBankName(bankName);
  }

/*
  @Post('uploadpolicy')
  @UseGuards(AuthGuard)
  @UseInterceptors(FileInterceptor('file')) // 'file' should match the field name in the form
  async uploadPolicy(
    @UploadedFile() file: Express.Multer.File,
    @Body('policy_title') policyTitle: string,
  ): Promise<Policy> {
    return this.bankService.createPolicy(policyTitle, file.buffer);
  }
*/

@Post('uploadpolicy')
  @UseGuards(AuthGuard)
  @UseInterceptors(FileInterceptor('file', {
    limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
    fileFilter: (req, file, cb) => {
      if (file.mimetype !== 'application/pdf') {
        return cb(new BadRequestException('Only PDF files are allowed'), false);
      }
      cb(null, true);
    },
  }))
  async uploadPolicy(
    @UploadedFile() file: Express.Multer.File,
    @Body('policy_title') policyTitle: string,
  ): Promise<Policy> {
    if (!file) {
      throw new BadRequestException('File is required');
    }
    try {
      return this.bankService.createPolicy(policyTitle, file.buffer);
    } catch (error) {
      if (error instanceof MulterError && error.code === 'LIMIT_FILE_SIZE') {
        throw new BadRequestException('File size exceeds the 5 MB limit');
      }
      throw error;
    }
  }


  @Post('password-reset')
  async handlePasswordReset(
    @Body('username') username: string,
    @Body('email') email: string,
    @Body('newPassword') newPassword?: string,
    @Body('otp') otp?: string,
  ) {
    return this.adminService.handlePasswordReset(username, email, newPassword, otp);
  }
  



}


