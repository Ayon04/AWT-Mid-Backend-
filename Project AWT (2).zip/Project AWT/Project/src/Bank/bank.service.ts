import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Account,Loan,Transaction,Performance,customer, Policy } from './bank.entity';

@Injectable()
export class BankService {
  constructor(
    @InjectRepository(customer)
    private readonly customerRepository: Repository<customer>,
    
    @InjectRepository(Policy)

    private readonly policyRepository: Repository<Policy>,
    
    @InjectRepository(Account)
    private readonly accountRepository: Repository<Account>,

    @InjectRepository(Loan)
    private readonly loanRepository: Repository<Loan>,

    @InjectRepository(Transaction)
    private readonly transactionRepository: Repository<Transaction>,

    @InjectRepository(Performance)
    private readonly performanceRepository: Repository<Performance>,
  ) {}

  async findAllCustomers(): Promise<customer[]> {
    return this.customerRepository.find();
  }

  async findAllAccounts(): Promise<Account[]> {
    return this.accountRepository.find();
  }

  async findAllLoans(): Promise<Loan[]> {
    return this.loanRepository.find();
  }

  async findAllTransactions(): Promise<Transaction[]> {
    return this.transactionRepository.find();
  }

  async findAllPerformances(): Promise<Performance[]> {
    return this.performanceRepository.find();
  }



  async findCustomerById(id: number): Promise<customer> {
    return this.customerRepository.findOneBy({ customer_id: id });
  }

  async findCustomersByBankName(bankName: string): Promise<customer[]> {
    return this.customerRepository.find({
      where: { branch_name: bankName },
    });
  }




  async createPolicy(policyTitle: string, file: Buffer): Promise<Policy> {
    const newPolicy = this.policyRepository.create({ policy_title: policyTitle, file });
    return this.policyRepository.save(newPolicy);
  }
}
