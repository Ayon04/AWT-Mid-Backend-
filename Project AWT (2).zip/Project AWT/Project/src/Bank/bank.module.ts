import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { customer } from './bank.entity'; // Ensure this uses the capitalized entity name
import { BankService } from './bank.service';
import { Account } from './bank.entity'; // Add other entities if they're in the same file
import { Loan } from './bank.entity';
import { Transaction } from './bank.entity';
import { Performance,Policy } from './bank.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([customer, Account, Loan, Transaction, Performance,Policy]),
  ],
  providers: [BankService],
  exports: [BankService],
})
export class BankModule {}
