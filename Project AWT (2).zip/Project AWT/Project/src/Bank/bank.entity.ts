
import { PrimaryGeneratedColumn, Column,PrimaryColumn, Entity, OneToMany, BeforeInsert } from "typeorm";

@Entity("transaction")
export class Transaction
{
  @PrimaryColumn()
  trant_id: number;

  @Column()
  sender_ac_no: number;

  @Column()
  receiver_ac_no: number;

  @Column()
  sending_branch: string;

  @Column()
  receiving_branch: string;

  @Column()
  amount:number

  @Column()
  current_balance:number
   
  @Column()
  transiction_by:number


}


@Entity('account')
export class Account {
  @PrimaryColumn()
  account_no: number;
  
  @Column()
  current_balance: number;

  @Column()
  status: string;

  @Column()
  branch_name: string;
  
  @Column()
  customer_id: number;
 
}



@Entity('loan')
export class Loan {
  @PrimaryColumn()
  loan_application_id: number;

  @Column()
  applicants_name: string;

  @Column()
  applicants_mobile_no: string;

  @Column()
  applicants_profession: string;

  @Column()
  requested_amount: number;

  @Column()
  interest_percentage: number;

  @Column()
  loan_duration_months: number; // Duration in months

  @Column()   
  branch_name: string;
}



@Entity('performance')
export class Performance {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  branch_name: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  total_loan_amount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  total_balance_amount: number;

  @Column()
  total_no_of_employees: number;

  @Column()
  total_no_of_customers: number;

  @Column()
  total_no_of_transactions: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  total_earnings: number;

  @Column({ type: 'decimal', precision: 5, scale: 2 })
  customers_served_per_hour: number;

  @Column({ type: 'decimal', precision: 5, scale: 2 })
  transactions_per_hour: number;

  @Column()  
  overall_performance: string; // Assuming it's a descriptive string or could be a number/percentage
}





@Entity('customer')
export class customer {
  @PrimaryColumn()
  customer_id: number;

  @Column()
  customer_name: string;

  @Column()
  customer_mobile: string;

  @Column()
  date_of_birth: Date;

  @Column() 
  customer_nid_no: number;

  @Column()
  nominee_name: string;

  @Column()
  open_date: Date;

  @Column()
  account_type: string;

  @Column()
  customer_profession: string;

  @Column()
  branch_name: string;
  
  @Column()
  account_no: string;
  

  
 
}


@Entity('policy')
export class Policy {
  @PrimaryGeneratedColumn()
  policy_id: number;

  @Column()
  policy_title: string;

  @Column({ type: 'bytea' }) // Use 'bytea' for binary data (PDF)
  file: Buffer; 
}


