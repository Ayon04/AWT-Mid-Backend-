import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { AdminModule } from './admin/admin.module';
import { AdminProfile } from './admin/admin.entity'; // Adjust path as necessary
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './admin/auth/auth.service'; //
import { MailerModule } from '@nestjs-modules/mailer';


@Module({
  imports: [
    ConfigModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'postgres',
     host: 'localhost',
     port: 5432,
     username: 'postgres',
     password: '1234',
     database: 'Media Bank DB',//Change to your database name
     autoLoadEntities: true,
     entities: [__dirname + '/**/*.entity{.ts,.js}'],
     synchronize: true // Synchronize schema (not recommended for production)
    }),
    AdminModule,
    
  ],
})
export class AppModule {}



